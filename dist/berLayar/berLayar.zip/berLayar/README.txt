===========================================
berLayar - Free Version
===========================================

Terima kasih telah menggunakan berLayar versi gratis.

Cara Menggunakan:
1. Klik dua kali file "berLayar.exe".
2. Pada jendela yang terbuka, atur opsi yang diinginkan:
   - Aktifkan kamera (opsional)
   - Posisi kamera
   - Ukuran & Opacity kamera
   - FPS streaming
   - Ukuran layar streaming
   - Kualitas JPEG
3. Beberapa opsi bertanda (pro) hanya tersedia di versi Pro.
4. Klik tombol "Mulai" untuk memulai berbagi layar.
5. Buka browser pada perangkat lain dan akses alamat yang muncul di layar aplikasi (misalnya: http://192.168.x.x:2025).
6. Pastikan port (:2025) juga anda tulis di paling belakang.
7. Untuk menghentikan berbagi layar:
   - Tekan tombol "Berhenti" di aplikasi, atau
   - Tutup jendela aplikasi.

Catatan:
- Versi gratis ini selalu menggunakan monitor utama untuk berbagi layar.
- Fitur bertanda (pro) tidak dapat dipilih pada versi gratis.
- Pastikan perangkat Anda terhubung pada jaringan yang sama dengan perangkat penerima.

Selamat berLayar dan Berbagi Layar!
===========================================