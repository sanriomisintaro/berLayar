// static/js/script.js

window.onload = function () {
  // === Info lisensi (diinject dari template) ===
  const IS_PRO = !!window.BERLAYAR_IS_PRO;
  const LICENSE_NAME =
    (typeof window.BERLAYAR_LICENSE_NAME === 'string' && window.BERLAYAR_LICENSE_NAME)
      ? window.BERLAYAR_LICENSE_NAME
      : (IS_PRO ? 'Pro User' : 'Free User');

  // === UI helper (optional, aman kalau style.css tidak termuat) ===
  function ensureProTopbar() {
    let bar = document.getElementById('pro-topbar');
    if (!IS_PRO) {
      if (bar && bar.parentNode) bar.parentNode.removeChild(bar);
      return;
    }
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'pro-topbar';
      bar.style.position = 'fixed';
      bar.style.left = '0'; bar.style.right = '0'; bar.style.top = '0';
      bar.style.display = 'flex'; bar.style.alignItems = 'center'; bar.style.gap = '12px';
      bar.style.padding = '8px 12px'; bar.style.background = 'rgba(0,0,0,.35)'; bar.style.color = '#fff';
      bar.style.font = '600 13px/1 system-ui, -apple-system,"Segoe UI",Roboto,Arial,sans-serif';
      bar.style.backdropFilter = 'blur(6px)'; bar.style.zIndex = '10';

      const img = document.createElement('img');
      const logo = document.getElementById('logo');
      img.src = (window.BERLAYAR_LOGO_URL) || (logo ? logo.src : '');
      img.alt = 'Logo';
      img.style.height = '20px';

      const s1 = document.createElement('span'); s1.textContent = 'berLayar Pro';
      const s2 = document.createElement('span'); s2.style.opacity = '.7'; s2.textContent = '— ' + LICENSE_NAME;

      bar.appendChild(img); bar.appendChild(s1); bar.appendChild(s2);
      document.body.appendChild(bar);

      const lc = document.getElementById('logo-container');
      if (lc && !lc.dataset.bumped) { lc.style.marginTop = '36px'; lc.dataset.bumped = '1'; }
    } else {
      const spans = bar.querySelectorAll('span');
      if (spans.length >= 2) spans[1].textContent = '— ' + LICENSE_NAME;
    }
  }

  function ensureFreeWatermark() {
    let wm = document.getElementById('free-watermark');
    if (IS_PRO) {
      if (wm && wm.parentNode) wm.parentNode.removeChild(wm);
      return;
    }
    if (!wm) {
      wm = document.createElement('div');
      wm.id = 'free-watermark';
      wm.textContent = 'berLayar Free Version';
      wm.style.position = 'fixed'; wm.style.right = '12px'; wm.style.bottom = '12px';
      wm.style.font = '600 12px/1.2 system-ui, -apple-system,"Segoe UI",Roboto,Arial,sans-serif';
      wm.style.opacity = '.65'; wm.style.background = 'rgba(0,0,0,.5)'; wm.style.color = '#fff';
      wm.style.padding = '6px 8px'; wm.style.borderRadius = '6px'; wm.style.userSelect = 'none'; wm.style.zIndex = '10';
      document.body.appendChild(wm);
    }
  }

  ensureProTopbar();
  ensureFreeWatermark();

  // === Socket.IO koneksi & stream ===
  if (typeof io === 'undefined') {
    console.log('ERROR: Socket.IO client (io) belum tersedia. Pastikan web-socket.js dimuat lebih dulu.');
    return;
  }

  const socket = io({ transports: ['websocket', 'polling'] });

  const img = document.getElementById('screen');
  let firstFrameArrived = false;

  // Badge loading sampai frame pertama muncul
  const loadingBadge = document.createElement('div');
  loadingBadge.textContent = 'Menunggu koneksi…';
  Object.assign(loadingBadge.style, {
    position: 'fixed', left: '50%', top: '50%',
    transform: 'translate(-50%, -50%)',
    padding: '8px 12px', background: 'rgba(0,0,0,.6)', color: '#fff',
    borderRadius: '8px', font: '600 12px/1 system-ui, -apple-system,"Segoe UI",Roboto,Arial,sans-serif',
    zIndex: '11'
  });
  document.body.appendChild(loadingBadge);
  const hideLoading = () => loadingBadge.parentNode && loadingBadge.parentNode.removeChild(loadingBadge);

  socket.on('connect', () => {
    // optional; server kita tidak butuh start_stream, tapi tidak masalah kalau dikirim
    try { socket.emit('start_stream'); } catch (e) {}
  });

  socket.on('frame', (data) => {
    if (!img || !data || !data.image) return;
    img.src = 'data:image/jpeg;base64,' + data.image;
    if (!firstFrameArrived) { firstFrameArrived = true; hideLoading(); }
  });

  socket.on('disconnect', () => {
    firstFrameArrived = false;
    loadingBadge.textContent = 'Terputus. Mencoba menyambung ulang…';
    if (!loadingBadge.parentNode) document.body.appendChild(loadingBadge);
  });

  socket.on('connect_error', () => {
    if (!loadingBadge.parentNode) document.body.appendChild(loadingBadge);
    loadingBadge.textContent = 'Gagal terhubung. Coba lagi…';
  });

  // === Tombol fullscreen ===
  const fullscreenBtn = document.getElementById('fullscreenBtn');
  if (fullscreenBtn) {
    fullscreenBtn.addEventListener('click', () => {
      const el = img || document.documentElement;
      (el.requestFullscreen || el.webkitRequestFullscreen || el.msRequestFullscreen || function(){}).call(el);
    });
  }
};
