===========================================
berLayar Lite - Free Version
===========================================

Terima kasih telah menggunakan berLayar Lite versi gratis.

Cara Menggunakan:
1. Klik dua kali file "berLayar-lite.exe" atau jalankan dari Command Prompt.
2. Aplikasi akan langsung memulai berbagi layar dengan pengaturan default.
3. Pada console akan muncul alamat yang dapat diakses (misalnya: http://192.168.x.x:2025).
4. Buka browser pada perangkat lain yang terhubung di jaringan yang sama, lalu akses alamat tersebut.
5. Untuk menghentikan berbagi layar:
   - Tekan CTRL + C di console, atau
   - Tutup jendela console.

Catatan:
- Versi Lite menggunakan pengaturan default:
  * Monitor: Utama
  * FPS: 15
  * Ukuran layar: 100%
  * Kamera: Nonaktif
- Tidak ada opsi untuk mengubah pengaturan di versi ini.
- Pastikan perangkat Anda terhubung pada jaringan yang sama dengan perangkat penerima.

Selamat berLayar dan berbagi layar!
===========================================

Untuk donasi sukarela atau membeli Lisensi berLayar Pro 
Kunjungi https://trakteer.id/berLayar/