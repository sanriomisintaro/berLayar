Cara menggunakan:
- Klik dua kali BerbagiLayar.exe
- Buka browser dan akses alamat yang muncul
- Untuk berhenti, tekan CTRL+C atau tutup jendela
